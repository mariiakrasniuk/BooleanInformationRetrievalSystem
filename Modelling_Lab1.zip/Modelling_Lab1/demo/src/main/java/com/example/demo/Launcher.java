package com.example.demo;

public class Launcher {
    public static void main(String[] args) {
        BooleanInformationRetrievalSystem.launchApp(args);
    }
}

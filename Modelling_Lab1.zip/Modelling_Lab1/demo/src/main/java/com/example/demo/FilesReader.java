package com.example.demo;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Collectors;

public class FilesReader {
    public static String readDocumentContent(String fileName) {
        Path filePath = Paths.get(fileName);

        if (!fileExists(filePath)) {
            System.err.println("File not found: " + fileName);
            return "";
        }

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(filePath.toFile())))) {
            return reader.lines()
                    .map(line -> line.replaceAll("[,!?.]", ""))
                    .collect(Collectors.joining(" "));
        } catch (IOException e) {
            System.err.println("Error reading file: " + fileName);
            e.printStackTrace();
            return "";
        }
    }

    private static boolean fileExists(Path filePath) {
        return Files.exists(filePath) && Files.isRegularFile(filePath);
    }
}

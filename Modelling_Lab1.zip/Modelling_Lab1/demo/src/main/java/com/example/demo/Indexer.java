package com.example.demo;

import java.util.*;

public class Indexer {
    private Map<String, Set<Integer>> index;
    private int nextDocId;


    public Indexer() {
        this.index = new HashMap<>();
        this.nextDocId = 1;

    }

    public void indexDocument(Document document) {
        String[] words = document.getContent().toLowerCase().split("\\s+");
        for (String word : words) {
            index.computeIfAbsent(word, k -> new HashSet<>()).add(document.getId());
        }
    }

    public Set<Integer> search(String[] query) {
        Set<Integer> result = new HashSet<>(index.getOrDefault(query[0].toLowerCase(), Collections.emptySet()));
        for (int i = 1; i < query.length; i++) {
            result.retainAll(index.getOrDefault(query[i].toLowerCase(), Collections.emptySet()));
        }
        return result;
    }

    public int getNextDocId() {
        return nextDocId++;
    }
}

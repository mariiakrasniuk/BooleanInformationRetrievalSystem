package com.example.demo;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class BooleanInformationRetrievalSystem extends Application {
    private final Indexer indexer = new Indexer();
    private TextArea resultArea;
    private Operator selectedOperator = Operator.AND;


    public static void main(String[] args) {
        launchApp(args);
    }

    public static void launchApp(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Boolean Search System");

        TextField searchField = new TextField();
        resultArea = new TextArea();
        resultArea.setEditable(false);
        resultArea.setStyle("fx-background-color: red");
        Button searchButton = new Button("Search");
        searchButton.setPrefWidth(80);
        searchButton.setStyle("-fx-background-color: #EBDD60;");

        Button andButton = new Button("AND");
        Button orButton = new Button("OR");

        searchButton.setOnAction(event -> searchDocuments(searchField.getText(), selectedOperator));

        andButton.setOnAction(event -> selectedOperator = Operator.AND);
        orButton.setOnAction(event -> selectedOperator = Operator.OR);

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(10));
        HBox searchLine = new HBox(7);
        layout.setPadding(new Insets(10));

        searchLine.getChildren().addAll(andButton, orButton, searchButton);

        layout.getChildren().addAll(searchField, searchLine, resultArea);

        Scene scene = new Scene(layout, 400, 300);
        primaryStage.setScene(scene);
        indexMultipleDocuments("result_one.txt", "result_two.txt", "result_three.txt", "result_four.txt", "result_five.txt");

        primaryStage.show();
    }

    private void searchDocuments(String query, Operator operator) {
        if (query.trim().isEmpty()) {
            resultArea.setText("Please enter a valid search query.");
            return;
        }

        String[] queryWords = query.toLowerCase().split("\\s+");
        List<Set<Integer>> documentsContainingWords = new ArrayList<>();

        for (String word : queryWords) {
            Set<Integer> documents = indexer.search(new String[]{word});
            documentsContainingWords.add(documents);
        }

        Set<Integer> result;
        if (operator == Operator.AND) {
            result = performAND(documentsContainingWords);
        } else {
            result = performOR(documentsContainingWords);
        }

        displayResults(result, queryWords, operator);
    }

    private Set<Integer> performAND(List<Set<Integer>> sets) {
        Set<Integer> result = new HashSet<>(sets.get(0));
        for (int i = 1; i < sets.size(); i++) {
            result.retainAll(sets.get(i));
        }
        return result;
    }

    private Set<Integer> performOR(List<Set<Integer>> sets) {
        Set<Integer> result = new HashSet<>();
        for (Set<Integer> documents : sets) {
            result.addAll(documents);
        }
        return result;
    }

    private void displayResults(Set<Integer> result, String[] queryWords, Operator operator) {
        StringBuilder resultText = new StringBuilder();

        if (result.isEmpty()) {
            resultText.append("No matches.");
        } else {
            resultText.append("Documents containing ");

            if (operator == Operator.AND) {
                resultText.append("All of the words: ");
            } else {
                resultText.append("Any of the words: ");
            }

            resultText.append(Arrays.toString(queryWords)).append("\n");

            for (int docId : result) {
                resultText.append("Document ").append(docId).append("\n");
            }
        }

        resultArea.setText(resultText.toString());
    }


    private void indexMultipleDocuments(String... fileNames) {
        for (int i = 0; i < fileNames.length; i++) {
            String fileName = fileNames[i];
            String content = "";
            try {
                content = new String(Files.readAllBytes(Paths.get(fileName)));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            Document document = new Document(i + 1, content); // Document index starts from 1
            indexer.indexDocument(document);
        }
    }

    private enum Operator {
        AND, OR
    }
}
